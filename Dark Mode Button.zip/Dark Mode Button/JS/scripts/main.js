//Variables

//dark mode functions